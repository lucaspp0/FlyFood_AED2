﻿using FlyFoodGit.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlyFoodGit.controllers
{
    public class FlightController
    {
        public static bool register(Flight flight)
        {
            // TO DO
            throw new NotImplementedException();
        }
    }
}
